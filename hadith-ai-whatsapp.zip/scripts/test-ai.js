/**
 * Quick test for the AI integration with Novita.ai
 */
require('dotenv').config();
const { generateReply } = require('../src/bot/ai');

(async () => {
  console.log('Testing Hadith AI with Novita.ai...\n');
  console.log('Question: ما حكم الصلاة في وقت غير وقتها المحدد؟\n');

  const reply = await generateReply({
    text: 'ما حكم الصلاة في وقت غير وقتها المحدد؟',
    sender: 'test',
    senderName: 'Test User',
    jid: 'test@test',
    isGroup: false,
  });

  console.log('========== AI REPLY (WhatsApp-formatted) ==========\n');
  console.log(reply);
  console.log('\n====================================================\n');
})();
