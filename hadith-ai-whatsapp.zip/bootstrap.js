/**
 * Hadith AI - Auto-Bootstrap Script
 * منظمة حديث الإسلامية - طارق الفارس
 *
 * This script automatically:
 *   1. Checks if node_modules exists
 *   2. If not, runs `npm install --production` automatically
 *   3. Then loads and starts the main server.js
 *
 * Set THIS file as the "Main File" in Wispbyte.
 * It will handle everything else automatically.
 */

const { spawn, spawnSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const PROJECT_ROOT = __dirname;
const NODE_MODULES = path.join(PROJECT_ROOT, 'node_modules');
const PACKAGE_JSON = path.join(PROJECT_ROOT, 'package.json');
const SERVER_FILE = path.join(PROJECT_ROOT, 'server.js');

// ANSI colors for nice console output
const c = {
  reset: '\x1b[0m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  red: '\x1b[31m',
  cyan: '\x1b[36m',
  bold: '\x1b[1m',
};

function log(icon, msg) {
  console.log(`${c.cyan}[Bootstrap]${c.reset} ${icon} ${msg}`);
}

/**
 * Check if a path exists
 */
function exists(p) {
  try {
    return fs.existsSync(p);
  } catch (e) {
    return false;
  }
}

/**
 * Check if node_modules has the required packages
 */
function isDepsInstalled() {
  if (!exists(NODE_MODULES)) return false;

  // Check a few critical packages
  const critical = [
    'express',
    'dotenv',
    '@whiskeysockets/baileys',
    'socket.io',
    'axios',
    'qrcode',
    'pino',
    '@hapi/boom',
    'node-cache',
    'helmet',
    'cors',
    'compression',
  ];

  for (const pkg of critical) {
    if (!exists(path.join(NODE_MODULES, pkg))) {
      return false;
    }
  }
  return true;
}

/**
 * Run npm install --production synchronously
 */
function installDependencies() {
  log('📦', `${c.yellow}Installing dependencies (this may take 30-60 seconds)...${c.reset}`);

  // Try npm first
  try {
    const result = spawnSync('npm', ['install', '--production', '--no-audit', '--no-fund'], {
      cwd: PROJECT_ROOT,
      stdio: 'inherit',
      shell: true,
      env: { ...process.env, npm_config_loglevel: 'error' },
    });

    if (result.status === 0) {
      log('✅', `${c.green}Dependencies installed successfully!${c.reset}`);
      return true;
    }
  } catch (e) {
    log('⚠️', `npm failed: ${e.message}, trying yarn...`);
  }

  // Fallback to yarn
  try {
    const result = spawnSync('yarn', ['install', '--production'], {
      cwd: PROJECT_ROOT,
      stdio: 'inherit',
      shell: true,
    });

    if (result.status === 0) {
      log('✅', `${c.green}Dependencies installed with yarn!${c.reset}`);
      return true;
    }
  } catch (e) {
    log('⚠️', `yarn failed: ${e.message}, trying pnpm...`);
  }

  // Fallback to pnpm
  try {
    const result = spawnSync('pnpm', ['install', '--prod'], {
      cwd: PROJECT_ROOT,
      stdio: 'inherit',
      shell: true,
    });

    if (result.status === 0) {
      log('✅', `${c.green}Dependencies installed with pnpm!${c.reset}`);
      return true;
    }
  } catch (e) {
    log('❌', `${c.red}All package managers failed!${c.reset}`);
    return false;
  }

  return false;
}

/**
 * Verify a package can be required
 */
function testRequire(pkg) {
  try {
    require.resolve(pkg, { paths: [PROJECT_ROOT] });
    return true;
  } catch (e) {
    return false;
  }
}

/**
 * Validate that critical packages are loadable
 */
function validateInstall() {
  const critical = [
    'express',
    'dotenv',
    '@whiskeysockets/baileys',
    'socket.io',
    'axios',
    'qrcode',
    'pino',
    '@hapi/boom',
    'node-cache',
    'helmet',
    'cors',
    'compression',
  ];

  const missing = critical.filter((p) => !testRequire(p));

  if (missing.length > 0) {
    log('⚠️', `${c.yellow}Missing packages after install: ${missing.join(', ')}${c.reset}`);
    return false;
  }

  log('✅', `${c.green}All critical packages verified.${c.reset}`);
  return true;
}

/**
 * Start the server
 */
function startServer() {
  log('🚀', `Starting Hadith AI server...`);

  // Use spawn so the server is a proper child process
  // that inherits stdio (so logs appear in Wispbyte console)
  const serverProcess = spawn('node', [SERVER_FILE], {
    cwd: PROJECT_ROOT,
    stdio: 'inherit',
    env: process.env,
  });

  serverProcess.on('error', (err) => {
    log('❌', `${c.red}Failed to start server: ${err.message}${c.reset}`);
    process.exit(1);
  });

  serverProcess.on('exit', (code, signal) => {
    if (signal) {
      log('⚠️', `Server received signal: ${signal}`);
    }
    if (code && code !== 0) {
      log('❌', `${c.red}Server exited with code ${code}${c.reset}`);
    } else {
      log('👋', 'Server exited normally');
    }
    process.exit(code || 0);
  });

  // Forward signals to child process
  process.on('SIGINT', () => serverProcess.kill('SIGINT'));
  process.on('SIGTERM', () => serverProcess.kill('SIGTERM'));
  process.on('SIGHUP', () => serverProcess.kill('SIGHUP'));
}

// ===== Main bootstrap flow =====
(async () => {
  console.log('');
  console.log(`${c.bold}${c.green}╔══════════════════════════════════════════════════════╗${c.reset}`);
  console.log(`${c.bold}${c.green}║   Hadith AI - Auto Bootstrap                          ║${c.reset}`);
  console.log(`${c.bold}${c.green}║   منظمة حديث الإسلامية | طارق الفارس                  ║${c.reset}`);
  console.log(`${c.bold}${c.green}╚══════════════════════════════════════════════════════╝${c.reset}`);
  console.log('');

  // Step 1: Verify package.json exists
  if (!exists(PACKAGE_JSON)) {
    log('❌', `${c.red}package.json not found at ${PACKAGE_JSON}${c.reset}`);
    log('💡', 'Make sure all project files are uploaded to the server.');
    process.exit(1);
  }
  log('✅', `Found package.json`);

  // Step 2: Check if dependencies are installed
  if (isDepsInstalled()) {
    log('✅', `${c.green}Dependencies already installed.${c.reset}`);
  } else {
    log('📦', `${c.yellow}Dependencies missing. Auto-installing...${c.reset}`);

    const installed = installDependencies();
    if (!installed) {
      log('❌', `${c.red}Failed to install dependencies automatically.${c.reset}`);
      log('💡', 'Try running this in the server terminal:');
      console.log('     npm install --production');
      process.exit(1);
    }

    // Verify install
    if (!validateInstall()) {
      log('⚠️', `${c.yellow}Install completed but some packages are missing. Retrying...${c.reset}`);
      installDependencies();
      if (!validateInstall()) {
        log('❌', `${c.red}Packages still missing after retry.${c.reset}`);
        process.exit(1);
      }
    }
  }

  // Step 3: Verify server.js exists
  if (!exists(SERVER_FILE)) {
    log('❌', `${c.red}server.js not found at ${SERVER_FILE}${c.reset}`);
    process.exit(1);
  }
  log('✅', `Found server.js`);

  // Step 4: Start the server
  console.log('');
  startServer();
})();
