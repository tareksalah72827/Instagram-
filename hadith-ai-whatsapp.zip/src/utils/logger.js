/**
 * Hadith AI - Logger Utility
 * منظمة حديث الإسلامية - طارق الفارس
 */

const pino = require('pino')({
  level: process.env.LOG_LEVEL || 'info',
  transport: {
    target: 'pino-pretty',
    options: {
      colorize: true,
      translateTime: 'yyyy-mm-dd HH:MM:ss',
      ignore: 'pid,hostname',
    },
  },
});

// Pretty-print wrapper (for non-pino logs)
function fmt(level, icon, ...args) {
  const ts = new Date().toISOString().replace('T', ' ').substring(0, 19);
  const parts = args.map((a) => (typeof a === 'object' ? JSON.stringify(a) : String(a)));
  console.log(`[${ts}] ${icon} ${level.toUpperCase().padEnd(5)} | ${parts.join(' ')}`);
}

module.exports = {
  pino,
  info: (...a) => fmt('info', '🔵', ...a),
  success: (...a) => fmt('success', '✅', ...a),
  warn: (...a) => fmt('warn', '🟡', ...a),
  error: (...a) => fmt('error', '🔴', ...a),
  debug: (...a) => {
    if (process.env.LOG_LEVEL === 'debug') fmt('debug', '🔍', ...a);
  },
};
