/**
 * Hadith AI - WhatsApp Bot Module
 * منظمة حديث الإسلامية - مؤسس: طارق الفارس
 *
 * Uses @whiskeysockets/baileys for WhatsApp Web automation.
 * Supports: QR Code auth, 8-digit Pairing Code, Typing indicator, Session persistence.
 */

const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  makeCacheableSignalKeyStore,
  Browsers,
} = require('@whiskeysockets/baileys');
const { Boom } = require('@hapi/boom');
const qrcode = require('qrcode');
const path = require('path');
const fs = require('fs');
const logger = require('../utils/logger');

// Use node-cache for message retry counter
const NodeCache = require('node-cache');
const msgRetryCounterCache = new NodeCache();

let sock = null;
let lastQR = null;
let lastPairingCode = null;
let connectionStatus = 'disconnected'; // disconnected | connecting | connected | ready
let connectionInfo = null;
let io = null;
let aiHandler = null;
let stats = {
  totalMessages: 0,
  totalReplies: 0,
  totalErrors: 0,
  startTime: null,
  lastMessageAt: null,
  activeChats: new Set(),
};

/**
 * Initialize the WhatsApp socket connection
 * @param {Object} options - { io: Socket.IO server, onMessage: async (msg) => replyText }
 */
async function initWhatsApp(options = {}) {
  io = options.io || null;
  aiHandler = options.onMessage || null;

  const sessionName = process.env.SESSION_NAME || 'hadith-ai-session';
  const authFolder = path.join(process.cwd(), 'auth_info', sessionName);

  if (!fs.existsSync(authFolder)) {
    fs.mkdirSync(authFolder, { recursive: true });
  }

  const { state, saveCreds } = await useMultiFileAuthState(authFolder);
  const { version, isLatest } = await fetchLatestBaileysVersion();

  logger.info(`Using Baileys version: ${version} (latest: ${isLatest})`);

  sock = makeWASocket({
    version,
    auth: state,
    printQRInTerminal: false,
    browser: Browsers.macOS('Hadith-AI'),
    markOnlineOnConnect: false,
    generateHighQualityLinkPreview: true,
    msgRetryCounterCache,
    defaultQueryTimeoutMs: 60000,
    connectTimeoutMs: 30000,
    keepAliveIntervalMs: 20000,
    logger: require('../utils/logger').pino,
    getMessage: async (key) => {
      // Used for retry; return null if message not in store
      return null;
    },
  });

  connectionStatus = 'connecting';
  broadcastStatus();

  // Save credentials on update
  sock.ev.on('creds.update', saveCreds);

  // Connection updates
  sock.ev.on('connection.update', async (update) => {
    const { connection, lastDisconnect, qr, pairingCode } = update;

    if (qr) {
      lastQR = qr;
      // Generate QR as data URL for the admin UI
      try {
        const qrDataUrl = await qrcode.toDataURL(qr, {
          width: 512,
          margin: 2,
          color: { dark: '#0a5c36', light: '#ffffff' },
        });
        if (io) io.emit('qr', { qr: qrDataUrl, raw: qr });
        logger.info('QR Code generated and sent to admin UI');
      } catch (e) {
        logger.error('Failed to generate QR image:', e.message);
      }
    }

    if (pairingCode) {
      lastPairingCode = pairingCode;
      if (io) io.emit('pairing_code', { code: pairingCode });
      logger.info(`Pairing code generated: ${pairingCode}`);
    }

    if (connection === 'close') {
      const statusCode = new Boom(lastDisconnect?.error)?.output?.statusCode;
      const shouldReconnect = statusCode !== DisconnectReason.loggedOut;

      connectionStatus = 'disconnected';
      broadcastStatus();

      if (shouldReconnect) {
        logger.warn(`Connection closed (code ${statusCode}). Reconnecting in 3s...`);
        setTimeout(() => initWhatsApp({ io, onMessage: aiHandler }), 3000);
      } else {
        logger.error('Connection closed permanently (logged out). Please re-scan QR.');
        // Clear session folder so next start shows fresh QR
        try {
          fs.rmSync(authFolder, { recursive: true, force: true });
        } catch (e) {}
      }
    } else if (connection === 'open') {
      connectionStatus = 'connected';
      const user = sock.user;
      connectionInfo = {
        id: user?.id,
        name: user?.name || user?.notify || 'Hadith AI',
        number: user?.id?.split(':')[0] || '',
      };
      stats.startTime = stats.startTime || Date.now();
      lastQR = null;
      lastPairingCode = null;
      broadcastStatus();
      broadcastInfo();
      logger.success(`WhatsApp connected as ${connectionInfo.number}`);
      if (io) io.emit('ready', connectionInfo);
    }
  });

  // Incoming messages
  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    if (type !== 'notify') return;

    for (const msg of messages) {
      try {
        await handleMessage(msg);
      } catch (e) {
        logger.error('Error handling message:', e.message);
        stats.totalErrors++;
      }
    }
  });

  // Presence updates (typing indicators from others)
  sock.ev.on('presence.update', ({ id, presences }) => {
    if (io) io.emit('presence', { id, presences });
  });

  return sock;
}

/**
 * Handle an incoming WhatsApp message
 */
async function handleMessage(msg) {
  // Skip if no message content
  if (!msg.message) return;

  // Skip status broadcasts
  if (msg.key.remoteJid === 'status@broadcast') return;

  // Skip messages sent by the bot itself
  if (msg.key.fromMe) return;

  const jid = msg.key.remoteJid;
  const isGroup = jid.endsWith('@g.us');

  // Respect group setting
  if (isGroup && process.env.REPLY_GROUPS !== 'true') return;

  // In groups, only reply when mentioned or it's a reply to bot
  if (isGroup) {
    const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
    const quotedMe = msg.message?.extendedTextMessage?.contextInfo?.participant === sock?.user?.id;
    if (!mentioned.includes(sock?.user?.id) && !quotedMe) return;
  }

  // Extract text
  const text =
    msg.message?.conversation ||
    msg.message?.extendedTextMessage?.text ||
    msg.message?.imageMessage?.caption ||
    msg.message?.videoMessage?.caption ||
    '';

  if (!text || text.trim().length === 0) return;

  const sender = msg.key.participant || jid;
  const senderName = msg.pushName || sender.split('@')[0];

  stats.totalMessages++;
  stats.lastMessageAt = Date.now();
  stats.activeChats.add(jid);

  // Broadcast incoming message to admin UI
  if (io) {
    io.emit('message:incoming', {
      id: msg.key.id,
      jid,
      sender,
      senderName,
      text,
      isGroup,
      timestamp: Date.now(),
    });
  }

  logger.info(`📩 [${isGroup ? 'GROUP' : 'DM'}] ${senderName}: ${text.substring(0, 80)}${text.length > 80 ? '...' : ''}`);

  // Show typing indicator
  if (process.env.SHOW_TYPING !== 'false') {
    try {
      await sock.sendPresenceUpdate('composing', jid);
    } catch (e) {}
  }

  // Get AI response
  if (!aiHandler) {
    logger.warn('No AI handler registered');
    return;
  }

  try {
    const typingDelay = parseInt(process.env.TYPING_DELAY || '1500', 10);
    const startTime = Date.now();

    const replyText = await aiHandler({
      text,
      sender,
      senderName,
      jid,
      isGroup,
    });

    const elapsed = Date.now() - startTime;
    if (elapsed < typingDelay) {
      await new Promise((r) => setTimeout(r, typingDelay - elapsed));
    }

    // Stop typing indicator
    if (process.env.SHOW_TYPING !== 'false') {
      try {
        await sock.sendPresenceUpdate('paused', jid);
      } catch (e) {}
    }

    if (!replyText) return;

    // Send the reply (WhatsApp supports *bold*, _italic_, ~strike~, ```code```)
    const sent = await sock.sendMessage(jid, { text: replyText });

    stats.totalReplies++;
    if (io) {
      io.emit('message:outgoing', {
        id: sent?.key?.id,
        jid,
        text: replyText,
        timestamp: Date.now(),
      });
    }

    logger.success(`✅ Reply sent to ${senderName}`);
  } catch (e) {
    logger.error('Failed to generate/send AI reply:', e.message);
    stats.totalErrors++;
    try {
      await sock.sendMessage(jid, {
        text: '⚠️ عذراً، حدث خطأ أثناء معالجة سؤالك. يرجى المحاولة مرة أخرى بعد لحظات.',
      });
    } catch (_) {}
  }
}

/**
 * Request a pairing code for phone number login
 * @param {string} phoneNumber - International format without + (e.g. 201001234567)
 */
async function requestPairingCode(phoneNumber) {
  if (!sock) throw new Error('Bot not initialized');
  if (connectionStatus === 'connected' || connectionStatus === 'ready') {
    throw new Error('البوت متصل بالفعل. يجب تسجيل الخروج أولاً.');
  }

  // Clean phone number
  const clean = phoneNumber.replace(/[^\d]/g, '');
  if (clean.length < 8) throw new Error('رقم الهاتف غير صالح');

  const code = await sock.requestPairingCode(clean);
  lastPairingCode = code;
  if (io) io.emit('pairing_code', { code });
  logger.info(`Pairing code requested for ${clean}: ${code}`);
  return code;
}

/**
 * Logout and clear session
 */
async function logout() {
  if (sock) {
    try {
      await sock.logout();
    } catch (e) {}
  }
  const sessionName = process.env.SESSION_NAME || 'hadith-ai-session';
  const authFolder = path.join(process.cwd(), 'auth_info', sessionName);
  try {
    fs.rmSync(authFolder, { recursive: true, force: true });
  } catch (e) {}
  connectionStatus = 'disconnected';
  connectionInfo = null;
  lastQR = null;
  lastPairingCode = null;
  broadcastStatus();
  logger.warn('Logged out. Session cleared.');
  // Re-init to show fresh QR
  setTimeout(() => initWhatsApp({ io, onMessage: aiHandler }), 1500);
}

function getSocket() {
  return sock;
}

function getStatus() {
  return {
    status: connectionStatus,
    info: connectionInfo,
    qr: lastQR,
    pairingCode: lastPairingCode,
    stats: {
      totalMessages: stats.totalMessages,
      totalReplies: stats.totalReplies,
      totalErrors: stats.totalErrors,
      uptime: stats.startTime ? Date.now() - stats.startTime : 0,
      lastMessageAt: stats.lastMessageAt,
      activeChats: stats.activeChats.size,
    },
  };
}

function broadcastStatus() {
  if (io) io.emit('status', getStatus());
}

function broadcastInfo() {
  if (io) io.emit('info', connectionInfo);
}

module.exports = {
  initWhatsApp,
  requestPairingCode,
  logout,
  getSocket,
  getStatus,
};
