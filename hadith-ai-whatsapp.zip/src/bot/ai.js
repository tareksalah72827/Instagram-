/**
 * Hadith AI - Artificial Intelligence Module
 * منظمة حديث الإسلامية - مؤسس: طارق الفارس
 *
 * Integrates with Novita.ai (OpenAI-compatible API) using deepseek-v4-pro.
 * Uses the official Hadith AI system prompt for Islamic jurisprudence answers.
 */

const axios = require('axios');
const logger = require('../utils/logger');

// ====== The Official Hadith AI System Prompt ======
const HADITH_AI_SYSTEM_PROMPT = `أنت الآن Hadith AI التابع لمنظمة حديث الإسلامية التي أسسها طارق الفارس
الاسم: Hadith AI
المؤسس: طارق الفارس
الجهة: منظمة حديث الإسلامية

-المهمة:
مهمتك هي الإجابة عن الأسئلة الشرعية والفقهية والعقائدية والتفسيرية بدقة ووضوح، والاعتماد الكامل على المصادر الموثوقة من القرآن الكريم والسنة النبوية والمذاهب الأربعة، وفق منهج أهل السنة والجماعة.
يجب أن تكون إجاباتك علمية، فصيحة، واضحة، مباشرة، دون غموض أو استخدام للأساليب الأدبية أو القصصية.

-الدقة:
"قبل الإجابة، قم بتحليل السؤال تحليلًا لغويًا وشرعيًا دقيقً: فكّ ألفاظه، حدّد مراد السائل، بيّن أيّ غموض أو افتراضات ضمنية، واستشهد بالأدلة الفقهية والنصوص المناسبة مع توضيح درجة اليقين."

-المصادر الأساسية:
1. القرآن الكريم وتفاسيره المعتبرة:
الطبري، ابن كثير، القرطبي، البغوي، السعدي، النفَسي..جميع كتب التفسير المعتمدة الصحيحة.
2. السنة النبوية الصحيحة من كتب الحديث المعتمدة:
صحيح البخاري، صحيح مسلم، سنن أبي داود، سنن الترمذي، سنن النسائي، سنن ابن ماجه، موطأ مالك، مسند أحمد، مصنف عبد الرزاق، مصنف ابن أبي شيبة.
3. المذاهب الأربعة الفقهية:
الحنفي، المالكي، الشافعي، الحنبلي.
مع الالتزام بأقوال أئمتها المعتبرة وفروعها المعتمدة.

⚖️ منهج الترجيح والفتوى:
عند الخلاف بين العلماء، يُقدَّم قول الجمهور.
إن لم يوجد قول جمهور، يُرجَّح القول الأقوى بالدليل الصحيح من الكتاب والسنة.
لا تُصدر فتوى إلا إذا كانت مدعومة بدليل شرعي صحيح أو بقول عالم معتبر.

-منهج العقيدة:
تتبع العقيدة الإسلامية وفق منهج أهل السنة والجماعة.
ترد على الفرق المنحرفة ردًا علميًا هادئًا بالبرهان والدليل الشرعي.

-العلماء المعاصرون الذين يُستأنس بأقوالهم:
ابن باز، ابن عثيمين، الألباني، الفوزان، صالح آل الشيخ، عبد الكريم الخضير، وغيرهم من جميع العلماء الموثوقين.

-المرجعية الإعلامية:
أنت مطّلع على قناة "حديث" على اليوتيوب التابعة للمؤسس طارق الفارس، ويمكنك الإجابة عن أي سؤال يخصها أو محتواها.
رابط القناة: https://youtube.com/@hadith_1?si=TIO1FNbLkscJgyyO

-الأسلوب العام:
الأسلوب علمي فصيح وواضح.
الرد وقور ومحترم.
خالٍ من الغموض أو الأساليب الأدبية.
يعتمد النصوص الشرعية والدلائل الصحيحة.
استخدم إيموجيات لائقة في الإجابة مع تنسيق الإجابة بشكل جميل ومرتب.

-تنسيق الرد:
تنسيق الرد يكون منسقًا بـ Markdown منظم.
استخدم العناوين الفرعية (##)، والنقاط (-)، والاقتباسات (>) للنصوص الشرعية، والتنسيق العريض (*) للكلمات المهمة، والمنسق (\` \` \`) للأدلة إذا لزم.

-قواعد إضافية للرد عبر واتساب:
1. لا تستخدم الروابط الخارجية إلا إذا كانت من المصادر المذكورة.
2. إذا كان السؤال خارج نطاق الفقه والعقيدة والتفسير، اعتذر بأدب وأرشد السائل إلى تخصص السؤال.
3. اجعل الرد متوسط الطول، لا مختصرًا جدًا ولا مطولًا بما يُتعب القارئ.
4. ابدأ الرد بتحية مناسبة (السلام عليكم ورحمة الله) في أول رسالة فقط من المحادثة.
5. اختم الرد بدعاء قصير أو جملة فقهية مناسبة (مثل: "والله أعلم").
6. حافظ على وقار الرد ولا تستخدم رموزًا تعبيرية مفرطة.`;

// ====== Conversation memory (per JID) ======
// Stores last N messages per chat for context
const conversationHistory = new Map();
const MAX_HISTORY_PER_CHAT = 6;
const HISTORY_TTL_MS = 30 * 60 * 1000; // 30 minutes

/**
 * Get conversation history for a JID (creates empty array if missing)
 */
function getHistory(jid) {
  if (!conversationHistory.has(jid)) {
    conversationHistory.set(jid, { messages: [], lastUpdate: Date.now() });
  }
  const entry = conversationHistory.get(jid);
  // Expire history if too old
  if (Date.now() - entry.lastUpdate > HISTORY_TTL_MS) {
    entry.messages = [];
  }
  entry.lastUpdate = Date.now();
  return entry.messages;
}

/**
 * Add a message to history and trim to max size
 */
function pushHistory(jid, role, content) {
  const history = getHistory(jid);
  history.push({ role, content });
  while (history.length > MAX_HISTORY_PER_CHAT) {
    history.shift();
  }
}

/**
 * Clean expired histories periodically (every 10 minutes)
 */
setInterval(() => {
  const now = Date.now();
  for (const [jid, entry] of conversationHistory.entries()) {
    if (now - entry.lastUpdate > HISTORY_TTL_MS) {
      conversationHistory.delete(jid);
    }
  }
}, 10 * 60 * 1000).unref?.();

/**
 * Convert Markdown to WhatsApp formatting
 * WhatsApp supports: *bold*, _italic_, ~strike~, ```code```
 * Does NOT support: # headings, > blockquotes, - lists
 * So we transform them into WhatsApp-compatible equivalents.
 */
function markdownToWhatsApp(md) {
  if (!md) return '';

  let text = md;

  // Convert headings ## and # to uppercase with emoji bullet
  text = text.replace(/^#{1,6}\s+(.+)$/gm, (_, t) => {
    return `\n*${t.trim()}*\n`;
  });

  // Convert bold **text** or __text__ to *text*
  text = text.replace(/\*\*(.+?)\*\*/g, '*$1*');
  text = text.replace(/__(.+?)__/g, '*$1*');

  // Convert italic _text_ or *text* (single) to _text_
  // Careful: don't touch already-converted bold
  text = text.replace(/(?<!\*)\*(?!\*)([^*\n]+?)\*(?!\*)/g, '_$1_');

  // Convert strikethrough ~~text~~ to ~text~
  text = text.replace(/~~(.+?)~~/g, '~$1~');

  // Convert inline code `text` to WhatsApp monospace
  text = text.replace(/`([^`\n]+?)`/g, '`$1`');

  // Convert blockquotes > text to indented italic
  text = text.replace(/^>\s+(.+)$/gm, '_$1_');

  // Convert bullet lists - or * to WhatsApp bullet
  text = text.replace(/^[\s]*[-*]\s+(.+)$/gm, '• $1');

  // Convert numbered lists 1. to bullet with number
  text = text.replace(/^[\s]*(\d+)\.\s+(.+)$/gm, '$1⃣ $2');

  // Collapse multiple blank lines
  text = text.replace(/\n{3,}/g, '\n\n');

  // Trim leading whitespace lines
  text = text.split('\n').map((l) => l.replace(/\s+$/g, '')).join('\n');

  return text.trim();
}

/**
 * Generate an AI response for a user message
 * @param {Object} params - { text, sender, senderName, jid, isGroup }
 * @returns {Promise<string>} - The formatted WhatsApp reply
 */
async function generateReply({ text, sender, senderName, jid, isGroup }) {
  const apiKey = process.env.AI_API_KEY;
  const apiUrl = process.env.AI_API_URL || 'https://api.novita.ai/openai';
  const model = process.env.AI_MODEL || 'deepseek/deepseek-v4-pro';
  const temperature = parseFloat(process.env.AI_TEMPERATURE || '0.3');
  const maxTokens = parseInt(process.env.AI_MAX_TOKENS || '2000', 10);

  if (!apiKey) {
    throw new Error('AI_API_KEY not configured');
  }

  // Build messages array with conversation history
  const history = getHistory(jid);

  const messages = [
    { role: 'system', content: HADITH_AI_SYSTEM_PROMPT },
  ];

  // Add conversation history (older messages)
  for (const h of history) {
    messages.push(h);
  }

  // Add current user message
  messages.push({
    role: 'user',
    content: isGroup
      ? `رسالة من ${senderName} في مجموعة: ${text}`
      : `رسالة من ${senderName}: ${text}`,
  });

  logger.debug(`Calling AI API with ${messages.length} messages`);

  const startTime = Date.now();

  try {
    const response = await axios.post(
      `${apiUrl}/v1/chat/completions`,
      {
        model,
        messages,
        temperature,
        max_tokens: maxTokens,
        stream: false,
      },
      {
        headers: {
          Authorization: `Bearer ${apiKey}`,
          'Content-Type': 'application/json',
        },
        timeout: 60000,
      }
    );

    const elapsed = Date.now() - startTime;
    const reply = response.data?.choices?.[0]?.message?.content?.trim();

    if (!reply) {
      throw new Error('Empty response from AI API');
    }

    logger.success(`🤖 AI replied in ${elapsed}ms (${reply.length} chars)`);

    // Save to history
    pushHistory(jid, 'user', text);
    pushHistory(jid, 'assistant', reply);

    // Convert Markdown to WhatsApp formatting
    const waFormatted = markdownToWhatsApp(reply);

    return waFormatted;
  } catch (error) {
    const elapsed = Date.now() - startTime;
    logger.error(`AI API error after ${elapsed}ms:`, error.message);

    if (error.response) {
      logger.error('API response status:', error.response.status);
      logger.error('API response data:', JSON.stringify(error.response.data));
    }

    // Return a graceful fallback message
    return '⚠️ عذراً، تعذّر الاتصال بخدمة الإجابة الفقهية حالياً. يرجى إعادة المحاولة بعد لحظات.\n\n* Hadith AI *';
  }
}

/**
 * Clear conversation history for a JID
 */
function clearHistory(jid) {
  conversationHistory.delete(jid);
}

/**
 * Get all active conversations
 */
function getConversations() {
  const result = [];
  for (const [jid, entry] of conversationHistory.entries()) {
    result.push({
      jid,
      messageCount: entry.messages.length,
      lastUpdate: entry.lastUpdate,
    });
  }
  return result;
}

module.exports = {
  generateReply,
  clearHistory,
  getConversations,
  markdownToWhatsApp,
  HADITH_AI_SYSTEM_PROMPT,
};
