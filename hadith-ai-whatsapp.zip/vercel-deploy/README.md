# Hadith AI - لوحة التحكم (Vercel Deployment)

> النسخة الخاصة بالنشر على Vercel — لوحة التحكم فقط (Frontend)
> البوت (Backend) يشتغل على السيرفر المنفصل.

## 📦 محتويات الحزمة

```
vercel-deploy/
├── index.html      # صفحة لوحة التحكم
├── vercel.json     # إعدادات Vercel (rewrites + CORS)
├── package.json    # معلومات الحزمة
└── README.md       # هذا الملف
```

## 🚀 خطوات النشر على Vercel

### 1) ارفع الملفات على GitHub
1. أنشئ repository جديد على GitHub باسم `hadith-ai-admin`
2. ارفع محتويات هذا المجلد (3 ملفات فقط) إليه

### 2) اربط Vercel بـ GitHub
1. اذهب إلى https://vercel.com
2. سجّل دخول بحساب GitHub
3. اضغط "Add New Project"
4. اختر الـ repository `hadith-ai-admin`
5. اضغط "Deploy" (بدون أي إعدادات — Vercel هيكتشف تلقائياً)

### 3) بعد النشر
- هتاخد رابط مثل: `https://hadith-ai-admin.vercel.app`
- اللوحة هتحاول تتصل تلقائياً بـ: `http://93.115.101.152:13999`
- لو غيّرت رابط السيرفر، افتح اللوحة واضغط على ⚙️ (إعدادات) وعدّل الرابط

## ⚠️ ملاحظات مهمة

1. **الـ Backend لازم يكون شغال على السيرفر** قبل ما تفتح اللوحة
2. **الـ CORS مُفعّل** على السيرفر — اللوحة على Vercel هتقدر تتصل
3. **لا ترفع `.env` أو `auth_info` على GitHub** — دي بس للوحة التحكم
4. **لو حبيت تستخدم HTTPS على السيرفر**، ضع `https://` بدل `http://` في إعدادات اللوحة
