/**
 * Hadith AI - Main Server
 * منظمة حديث الإسلامية - مؤسس: طارق الفارس
 *
 * WhatsApp Automation Bot for Islamic Jurisprudence Questions
 * Powered by Novita.ai (deepseek-v4-pro)
 */

require('dotenv').config();

const express = require('express');
const http = require('http');
const path = require('path');
const cors = require('cors');
const compression = require('compression');
const helmet = require('helmet');
const { Server: SocketIO } = require('socket.io');

const logger = require('./src/utils/logger');
const { initWhatsApp, requestPairingCode, logout, getSocket, getStatus } = require('./src/bot/whatsapp');
const { generateReply, clearHistory, getConversations } = require('./src/bot/ai');

// ===== Configuration =====
const PORT = process.env.PORT || 3000;
const ADMIN_USERNAME = process.env.ADMIN_USERNAME || 'admin';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'Hadith@AI2025';

// Simple session tokens (in-memory)
const sessions = new Map();
function makeToken() {
  return require('crypto').randomBytes(32).toString('hex');
}
function authMiddleware(req, res, next) {
  const token = req.headers.authorization?.replace('Bearer ', '');
  if (!token || !sessions.has(token)) {
    return res.status(401).json({ error: 'غير مصرح' });
  }
  req.token = token;
  next();
}

// ===== App =====
const app = express();
const server = http.createServer(app);

const io = new SocketIO(server, {
  cors: { origin: '*', methods: ['GET', 'POST'] },
  maxHttpBufferSize: 1e8,
});

app.use(helmet({ contentSecurityPolicy: false, crossOriginResourcePolicy: false }));
app.use(compression());
app.use(cors({ origin: true, credentials: true }));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// Serve static admin UI
app.use(express.static(path.join(__dirname, 'public')));

// ===== API Routes =====

// Health check
app.get('/api/health', (req, res) => {
  res.json({ ok: true, name: 'Hadith AI', version: '1.0.0', time: Date.now() });
});

// Login
app.post('/api/login', (req, res) => {
  const { username, password } = req.body;
  if (username === ADMIN_USERNAME && password === ADMIN_PASSWORD) {
    const token = makeToken();
    sessions.set(token, { user: username, createdAt: Date.now() });
    res.json({ token, username });
  } else {
    res.status(401).json({ error: 'بيانات الدخول غير صحيحة' });
  }
});

// Verify token
app.get('/api/me', authMiddleware, (req, res) => {
  res.json({ ok: true, user: sessions.get(req.token).user });
});

// Bot status
app.get('/api/status', authMiddleware, (req, res) => {
  res.json(getStatus());
});

// Request pairing code
app.post('/api/pairing-code', authMiddleware, async (req, res) => {
  try {
    const { phoneNumber } = req.body;
    if (!phoneNumber) return res.status(400).json({ error: 'رقم الهاتف مطلوب' });
    const code = await requestPairingCode(phoneNumber);
    res.json({ code });
  } catch (e) {
    logger.error('Pairing code error:', e.message);
    res.status(500).json({ error: e.message });
  }
});

// Logout / reset session
app.post('/api/logout', authMiddleware, async (req, res) => {
  try {
    await logout();
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Send a test message (admin can manually message a JID)
app.post('/api/send', authMiddleware, async (req, res) => {
  try {
    const { jid, text } = req.body;
    if (!jid || !text) return res.status(400).json({ error: 'jid and text are required' });
    const sock = getSocket();
    if (!sock) return res.status(503).json({ error: 'البوت غير متصل' });
    const sent = await sock.sendMessage(jid, { text });
    io.emit('message:outgoing', {
      id: sent?.key?.id,
      jid,
      text,
      timestamp: Date.now(),
    });
    res.json({ ok: true, id: sent?.key?.id });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Active conversations
app.get('/api/conversations', authMiddleware, (req, res) => {
  res.json(getConversations());
});

// Clear a conversation
app.delete('/api/conversations/:jid', authMiddleware, (req, res) => {
  clearHistory(req.params.jid);
  res.json({ ok: true });
});

// AI test endpoint
app.post('/api/test-ai', authMiddleware, async (req, res) => {
  try {
    const { question } = req.body;
    if (!question) return res.status(400).json({ error: 'question is required' });
    const reply = await generateReply({
      text: question,
      sender: 'admin',
      senderName: 'Admin Test',
      jid: 'test@test',
      isGroup: false,
    });
    res.json({ reply });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Catch-all → serve admin UI
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// ===== Socket.IO =====
io.on('connection', (socket) => {
  logger.info(`Admin UI connected (${socket.id})`);

  // Send current status immediately
  socket.emit('status', getStatus());

  socket.on('disconnect', () => {
    logger.debug(`Admin UI disconnected (${socket.id})`);
  });
});

// ===== Initialize WhatsApp Bot =====
initWhatsApp({
  io,
  onMessage: async (msg) => {
    return await generateReply(msg);
  },
}).catch((e) => {
  logger.error('Failed to initialize WhatsApp bot:', e.message);
});

// ===== Start Server =====
server.listen(PORT, () => {
  logger.success(`🚀 Hadith AI Server running on http://localhost:${PORT}`);
  logger.info(`📱 Admin UI: http://localhost:${PORT}/`);
  logger.info(`🔌 API: http://localhost:${PORT}/api/`);
  logger.info(`⚙️  Environment: ${process.env.NODE_ENV || 'development'}`);
});

// Graceful shutdown
process.on('SIGINT', () => {
  logger.warn('Shutting down...');
  server.close(() => process.exit(0));
});
process.on('SIGTERM', () => {
  server.close(() => process.exit(0));
});

module.exports = { app, server, io };
